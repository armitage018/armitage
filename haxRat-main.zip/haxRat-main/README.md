fast install Ubuntu in termux and start Ubuntu

apt update

apt install sudo

sudo apt install git

sudo apt install nano

sudo apt install nodejs

sudo apt install npm

sudo apt-get install openjdk-8-jdk

sudo apt install apktool

sudo apt install unzip

git clone https://github.com/sksohal7/l3mon.git

cd l3mon

unzip l3mon

cd l3mon

cd server

rm -rf package-lock.json

apt clean

npm install

npm install pm2 -g

pm2 start index.js

pm2 stop index.js

...................................

Ubuntu install command 

...................................



pkg update -y && pkg install wget curl proot tar -y && wget https://raw.githubusercontent.com/AndronixApp/AndronixOrigin/master/Installer/Ubuntu22/ubuntu22.sh -O ubuntu22.sh && chmod +x ubuntu22.sh && bash ubuntu22.sh


